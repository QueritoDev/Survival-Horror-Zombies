using System;
using System.Collections.Generic;
using System.Numerics;

public enum WaveState
{
    Intermission,     // esperando a próxima wave começar
    Spawning,         // spawnando inimigos aos poucos
    WaitingForClear   // já spawnou todos, esperando o jogador matar o resto
}

// Máquina de estados: Intermission -> Spawning -> WaitingForClear -> Intermission -> ...
// Importante: essa classe NUNCA chama Deactivate/mexe na vida do inimigo diretamente,
// só chama EnemyManager.Spawn(). Quem decide se um inimigo morre é sempre o Enemy (TakeDamage).
// Isso evita o tipo de bug de "inimigo sumir sozinho" por outro motivo que não seja morte.
public class WaveManager
{
    private readonly EnemyManager enemyManager;
    private readonly List<SpawnPoint> spawnPoints;
    private readonly Random random = new Random();

    public int CurrentWave { get; private set; } = 0;
    public WaveState State { get; private set; } = WaveState.Intermission;

    // quantos inimigos ainda faltam aparecer no mapa (contando os já vivos)
    public int EnemiesRemainingInWave =>
        (enemiesToSpawnThisWave - enemiesSpawnedThisWave) + enemyManager.AliveCount;

    private int enemiesToSpawnThisWave;
    private int enemiesSpawnedThisWave;

    private float spawnTimer;
    private readonly float spawnInterval = 1.2f;

    private float intermissionTimer = 5f; // tempo antes da wave 1 começar
    private const float IntermissionDuration = 8f;

    public event Action<int> OnWaveStart;
    public event Action<int> OnWaveComplete;

    public WaveManager(EnemyManager enemyManager, List<SpawnPoint> spawnPoints)
    {
        this.enemyManager = enemyManager;
        this.spawnPoints = spawnPoints;
    }

    public void Update(float dt)
    {
        switch (State)
        {
            case WaveState.Intermission:
                UpdateIntermission(dt);
                break;
            case WaveState.Spawning:
                UpdateSpawning(dt);
                break;
            case WaveState.WaitingForClear:
                UpdateWaitingForClear();
                break;
        }
    }

    private void UpdateIntermission(float dt)
    {
        intermissionTimer -= dt;
        if (intermissionTimer <= 0f)
            StartNextWave();
    }

    private void StartNextWave()
    {
        CurrentWave++;
        enemiesToSpawnThisWave = CalculateEnemiesForWave(CurrentWave);
        enemiesSpawnedThisWave = 0;
        spawnTimer = 0f;
        State = WaveState.Spawning;

        OnWaveStart?.Invoke(CurrentWave);
    }

    private void UpdateSpawning(float dt)
    {
        spawnTimer -= dt;

        bool aindaFaltaSpawnar = enemiesSpawnedThisWave < enemiesToSpawnThisWave;

        if (aindaFaltaSpawnar && spawnTimer <= 0f)
        {
            SpawnPoint escolhido = spawnPoints[random.Next(spawnPoints.Count)];

            // o EnemyManager já respeita o MAX_ENEMIES dele (o pool);
            // se estiver cheio, Spawn retorna false e a gente só tenta de novo no próximo frame
            if (enemyManager.Spawn(escolhido.Position))
            {
                enemiesSpawnedThisWave++;
                spawnTimer = spawnInterval;
            }
        }

        if (!aindaFaltaSpawnar)
            State = WaveState.WaitingForClear;
    }

    private void UpdateWaitingForClear()
    {
        if (enemyManager.AliveCount == 0)
        {
            State = WaveState.Intermission;
            intermissionTimer = IntermissionDuration;
            OnWaveComplete?.Invoke(CurrentWave);
        }
    }

    // Fórmula simples, fácil de ajustar depois pra calibrar dificuldade.
    private int CalculateEnemiesForWave(int wave)
    {
        return Math.Min(6 + 4 * (wave - 1), 30);
    }
}
