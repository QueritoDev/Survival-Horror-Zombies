using System.Numerics;

// Representa um ponto onde inimigos podem nascer no mapa.
public class SpawnPoint
{
    public Vector2 Position { get; }

    public SpawnPoint(Vector2 position)
    {
        Position = position;
    }
}
