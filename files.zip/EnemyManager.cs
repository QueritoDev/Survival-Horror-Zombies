using System.Numerics;
using System.Collections.Generic;
using Raylib_cs;

public class EnemyManager
{
    private readonly List<Enemy> enemies = new List<Enemy>();
    private const int MAX_ENEMIES = 15;

    // quantos inimigos estão vivos agora - o WaveManager usa isso
    public int AliveCount { get; private set; }

    // retorna true se conseguiu spawnar (reaproveitou ou criou), false se o pool está cheio
    public bool Spawn(Vector2 pos)
    {
        foreach (var enemy in enemies)
        {
            if (!enemy.IsAlive)
            {
                enemy.Activate(pos);
                return true;
            }
        }

        if (enemies.Count >= MAX_ENEMIES)
            return false;

        Enemy newEnemy = new Enemy(pos);
        enemies.Add(newEnemy);
        return true;
    }

    public void Update(float dt, Vector2 playerPos)
    {
        int alive = 0;
        foreach (var enemy in enemies)
        {
            enemy.Update(dt, playerPos);
            if (enemy.IsAlive) alive++;
        }
        AliveCount = alive;
    }

    public void Draw()
    {
        foreach (var enemy in enemies)
            enemy.Draw();
    }

    public bool TryDamage(IDamageable target, Rectangle targetRec, Rectangle attackRec, float amount)
    {
        if (Raylib.CheckCollisionRecs(attackRec, targetRec))
        {
            target.TakeDamage(amount);
            return true;
        }
        return false;
    }

    public void UnloadAll()
    {
        foreach (var enemy in enemies)
            enemy.Unload();
    }
}
